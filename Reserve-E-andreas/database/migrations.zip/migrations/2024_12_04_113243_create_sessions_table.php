<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->timestamps();
            $table->text('payload'); // Session data (serialized)
            $table->unsignedBigInteger('user_id')->nullable(); // Add user_id column (nullable)
            $table->ipAddress('ip_address')->nullable(); // IP address of the user session
            $table->string('user_agent')->nullable(); // User agent (browser/device)
            $table->integer('last_activity')->unsigned(); // Timestamp of last activity
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');
    }
};
